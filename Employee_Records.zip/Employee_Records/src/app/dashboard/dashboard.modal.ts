export class DashboardModal{
    id: number = 0;
    firstName : string = '';
    lastName : string = '';
    contactNumber: number = 0;
    emailAddress: string = '';
    dateOfBirth: string ='';
    streetAddress: string = ''
    city: string = '';
    postalCode: string = '';
    country: string = '';
    skill: string = '';
    yearsExp: number = 0;
    seniorityRate: string = '';
    //skills: Skill [];

}

// export class Skill {
//     skill: string = '';
//     yearsExp: string = '';
//     seniorityRate: number = 0;
// }