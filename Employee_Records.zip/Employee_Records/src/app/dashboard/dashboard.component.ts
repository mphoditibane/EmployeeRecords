import { Component, OnInit } from '@angular/core';
import { Form, FormArray, FormBuilder, FormGroup } from '@angular/forms';
import { ApiService } from '../shared/api.service';
import { DashboardModal } from './dashboard.modal';


@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.css']
})
export class DashboardComponent implements OnInit {
  display = "none";
  terms="";
  employeeData : any;
  numberOfEmp !: number;
  showSubmit !: boolean;
  showUpdate !: boolean;
  hideEmp !: boolean;
  showEmp !: boolean;
  formValue !: FormGroup;
  dashboardEmploObj : DashboardModal = new DashboardModal();
  empDropdown = [1, 2, 3];
  empList = [];
  selectedValue : any;
  constructor(private formbuilder : FormBuilder, private employeeApi : ApiService) { }

  ngOnInit(): void {
    
    this.formValue = this.formbuilder.group({
      firstName : [''],
      lastName : [''],
      contactNumber: [''],
      emailAddress: [''],
      dateOfBirth: [''],
      streetAddress: [''],
      city: [''],
      postalCode: [''],
      country: [''],
      skill: [''],
      yearsExp: [''],
      seniorityRate: [''],
      skills: this.formbuilder.array([this.addSkills()])
    });
    this.getAllEmployeeInfo();
  }

  
  valueSelected() {
    this.employeeData = this.employeeApi.getEmployeeInfo().forEach(
      item => item.id === this.selectedValue);
  }

  addSkills() {
    return this.formbuilder.group({
      skill: [''],
      yearsExp: [''],
      seniorityRate: ['']
    });
  }
  addSkillsGroup() {
    this.skillsArray.push(this.addSkills());
  }

  deleteSkillField(index: any) {
    this.skillsArray.removeAt(index);
  }
  get skillsArray() {
    return<FormArray>this.formValue.get('skills');
  }
  postEmployeeDetails() {
    this.dashboardEmploObj.firstName = this.formValue.value.firstName;
    this.dashboardEmploObj.lastName = this.formValue.value.lastName;
    this.dashboardEmploObj.contactNumber = this.formValue.value.contactNumber;
    this.dashboardEmploObj.emailAddress = this.formValue.value.emailAddress;
    this.dashboardEmploObj.dateOfBirth = this.formValue.value.dateOfBirth;
    this.dashboardEmploObj.streetAddress = this.formValue.value.streetAddress;
    this.dashboardEmploObj.city = this.formValue.value.city;
    this.dashboardEmploObj.postalCode = this.formValue.value.postalCode;
    this.dashboardEmploObj.country = this.formValue.value.country;
    this.dashboardEmploObj.skill = this.formValue.value.skill;
    this.dashboardEmploObj.yearsExp = this.formValue.value.yearsExp;
    this.dashboardEmploObj.seniorityRate = this.formValue.value.seniorityRate;

    this.employeeApi.postEmployeeInfo(this.dashboardEmploObj)
     .subscribe(res=>{
       console.log(res);
       alert('sucessfull added data');
       let cancelForm = document.getElementById('cancel');
       cancelForm?.click();
       this.formValue.reset();
       this.getAllEmployeeInfo();
     })

   console.log('values',this.formValue.value) 
  }

  getAllEmployeeInfo() {
    this.employeeApi.getEmployeeInfo()
     .subscribe(res =>{
      this.employeeData = res;
      console.log('data', this.employeeData);
      this.numberOfEmp = Object.keys(this.employeeData).length;
      if(this.numberOfEmp === 0){
        this.hideEmp = true;
        this.showEmp = false;
      } else {
        this.hideEmp = false;
        this.showEmp = true;
      }
      // for (let i = 0; i < this.employeeData.length; i++) {
      //   this.numberOfEmp = this.employeeData[i];
      //   console.log('num', this.numberOfEmp);
      //   if(this.numberOfEmp === 0){
      //     this.hideEmp = true;
      //     this.showEmp = false;
      //   } else {
      //     this.hideEmp = false;
      //     this.showEmp = true;
      //   }
      // }
    })
  }

  deleteRecord(emp: any) {
    this.employeeApi.deleteEmployeeInfo(emp.id)
    .subscribe(res =>{
      alert("Employee Record Deleted");
      this.getAllEmployeeInfo();
    });
  }

  editRecord(emp : any) {
    let openModalRef = document.getElementById("openModalEdit");
    openModalRef?.click();
    this.showSubmit = false;
    this.showUpdate = true;
    this.dashboardEmploObj.id = emp.id
    this.formValue.controls['firstName'].setValue(emp.firstName);
    this.formValue.controls['lastName'].setValue(emp.lastName);
    this.formValue.controls['contactNumber'].setValue(emp.contactNumber);
    this.formValue.controls['emailAddress'].setValue(emp.emailAddress);
    this.formValue.controls['dateOfBirth'].setValue(emp.dateOfBirth);
    this.formValue.controls['streetAddress'].setValue(emp.streetAddress);
    this.formValue.controls['city'].setValue(emp.city);
    this.formValue.controls['postalCode'].setValue(emp.postalCode);
    this.formValue.controls['country'].setValue(emp.country);
    this.formValue.controls['skill'].setValue(emp.skill);
    this.formValue.controls['yearsExp'].setValue(emp.yearsExp);
    this.formValue.controls['seniorityRate'].setValue(emp.seniorityRate);
  }

  updateEmployeeDetails(){

    this.dashboardEmploObj.firstName = this.formValue.value.firstName;
    this.dashboardEmploObj.lastName = this.formValue.value.lastName;
    this.dashboardEmploObj.contactNumber = this.formValue.value.contactNumber;
    this.dashboardEmploObj.emailAddress = this.formValue.value.emailAddress;
    this.dashboardEmploObj.dateOfBirth = this.formValue.value.dateOfBirth;
    this.dashboardEmploObj.streetAddress = this.formValue.value.streetAddress;
    this.dashboardEmploObj.city = this.formValue.value.city;
    this.dashboardEmploObj.postalCode = this.formValue.value.postalCode;
    this.dashboardEmploObj.country = this.formValue.value.country;
    this.dashboardEmploObj.skill = this.formValue.value.skill;
    this.dashboardEmploObj.yearsExp = this.formValue.value.yearsExp;
    this.dashboardEmploObj.seniorityRate = this.formValue.value.seniorityRate;

    this.employeeApi.updateEmployeeInfo(this.dashboardEmploObj,this.dashboardEmploObj.id)
      .subscribe(res=>{
        alert("successfully updated!");
        let cancelForm = document.getElementById('cancel');
        cancelForm?.click();
        this.formValue.reset();
        this.getAllEmployeeInfo();
      });
  }

  openModal() {
    this.display = "block";
    this.showSubmit = true;
    this.showUpdate = false;
    this.formValue.reset();
  }
  onCloseHandled() {
    this.display = "none";
  }


}


